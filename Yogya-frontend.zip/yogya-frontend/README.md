# Yogya Frontend 🎯

Single-file HTML frontend for the Yogya career platform.  
Deployed on **GitHub Pages** — no build step needed!

## Deploy on GitHub Pages

### Step 1 — Do the Backend first!
Complete the `yogya-backend` repo setup and get your Render URL before continuing.

### Step 2 — Update API URL in index.html
Open `index.html` and find line ~1028:
```js
const API_URL = 'https://YOUR-BACKEND-URL.onrender.com/api';
```
Replace with your actual Render URL:
```js
const API_URL = 'https://yogya-api.onrender.com/api';
```

### Step 3 — Push to GitHub
```bash
git init
git add .
git commit -m "Initial frontend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/yogya-frontend.git
git push -u origin main
```

### Step 4 — Enable GitHub Pages
1. Go to your `yogya-frontend` repo on GitHub
2. **Settings** → **Pages** (left sidebar)
3. **Source**: Deploy from a branch
4. **Branch**: `main` → folder: `/ (root)`
5. Click **Save**
6. Wait 1-2 mins → Your site is live at:
   `https://YOUR_USERNAME.github.io/yogya-frontend`

### Step 5 — Update Backend CORS (important!)
Go to your `yogya-backend` repo → Render dashboard → Environment Variables → Add:
```
CLIENT_URL = https://YOUR_USERNAME.github.io
```
Then redeploy the backend.

---

## That's it! 🎉
Your full website is now live with permanent data storage.
